-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2018 at 06:18 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tabulation`
--

-- --------------------------------------------------------

--
-- Table structure for table `contestant`
--

CREATE TABLE `contestant` (
  `id_contestant` int(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `team` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `candidate_no` int(100) NOT NULL,
  `picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contestant`
--

INSERT INTO `contestant` (`id_contestant`, `gender`, `team`, `full_name`, `candidate_no`, `picture`) VALUES
(1, 'Male', 'MIND STONE', 'Lourd Vincent Malaran', 1, 'mr_mind.jpg'),
(2, 'Female', 'MIND STONE', 'Diosdada Joy Fano', 1, 'ms_mind.jpg'),
(3, 'Male', 'POWER STONE', 'Mark Daryl Gonzaga', 2, 'mr_power.jpg'),
(4, 'Female', 'POWER STONE', 'Marchie Clenuar Arado', 2, 'ms_power.jpg'),
(5, 'Male', 'REALITY STONE', 'Carl Benson Cutanda', 3, 'mr_reality.jpg'),
(6, 'Female', 'REALITY STONE', 'Kristine Kaye Boltron', 3, 'ms_reality.jpg'),
(7, 'Male', 'SPACE STONE', 'Aldrin Louis Bagolor', 4, 'mr_space.jpg'),
(8, 'Female', 'SPACE STONE', 'Cherry Maigne Arandid', 4, 'ms_space.jpg'),
(9, 'Male', 'TIME STONE', 'Derick James Rejas', 5, 'mr_time.jpg'),
(10, 'Female', 'TIME STONE', 'Cristine Joy Milay', 5, 'ms_time.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(100) NOT NULL,
  `account_type` varchar(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `account_type`, `username`, `password`) VALUES
(1, 'judge', 'judge1', '111'),
(2, 'judge', 'judge2', '222'),
(3, 'judge', 'judge3', '333'),
(4, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `long_gown`
--

CREATE TABLE `long_gown` (
  `id` int(11) NOT NULL,
  `candidate_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `judge1` double NOT NULL,
  `judge2` double NOT NULL,
  `judge3` double NOT NULL,
  `average` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `long_gown`
--

INSERT INTO `long_gown` (`id`, `candidate_no`, `name`, `judge1`, `judge2`, `judge3`, `average`) VALUES
(1, 1, 'Lourd Vincent Malaran', 0, 0, 0, 0),
(2, 1, 'Diosdada Joy Fano', 0, 0, 0, 0),
(3, 2, 'Mark Daryl Gonzaga', 0, 0, 0, 0),
(4, 2, 'Marchie Clenuar Arado', 0, 0, 0, 0),
(5, 3, 'Carl Benson Cutanda', 0, 0, 0, 0),
(6, 3, 'Kristine Kaye Boltron', 0, 0, 0, 0),
(7, 4, 'Aldrin Louis Bagolor', 0, 0, 0, 0),
(8, 4, 'Cherry Maigne Arandid', 0, 0, 0, 0),
(9, 5, 'Derick James Rejas', 0, 0, 0, 0),
(10, 5, 'Cristine Joy Milay', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_no`
--

CREATE TABLE `production_no` (
  `id` int(11) NOT NULL,
  `candidate_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `judge1` double NOT NULL,
  `judge2` double NOT NULL,
  `judge3` double NOT NULL,
  `average` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `production_no`
--

INSERT INTO `production_no` (`id`, `candidate_no`, `name`, `judge1`, `judge2`, `judge3`, `average`) VALUES
(1, 1, 'Lourd Vincent Malaran', 0, 0, 0, 0),
(2, 1, 'Diosdada Joy Fano', 0, 0, 0, 0),
(3, 2, 'Mark Daryl Gonzaga', 0, 0, 0, 0),
(4, 2, 'Marchie Clenuar Arado', 0, 0, 0, 0),
(5, 3, 'Carl Benson Cutanda', 0, 0, 0, 0),
(6, 3, 'Kristine Kaye Boltron', 0, 0, 0, 0),
(7, 4, 'Aldrin Louis Bagolor', 0, 0, 0, 0),
(8, 4, 'Cherry Maigne Arandid', 0, 0, 0, 0),
(9, 5, 'Derick James Rejas', 0, 0, 0, 0),
(10, 5, 'Cristine Joy Milay', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_one`
--

CREATE TABLE `qa_one` (
  `id` int(11) NOT NULL,
  `candidate_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `judge1` double NOT NULL,
  `judge2` double NOT NULL,
  `judge3` double NOT NULL,
  `average` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qa_one`
--

INSERT INTO `qa_one` (`id`, `candidate_no`, `name`, `judge1`, `judge2`, `judge3`, `average`) VALUES
(1, 1, 'Lourd Vincent Malaran', 0, 0, 0, 0),
(2, 1, 'Diosdada Joy Fano', 0, 0, 0, 0),
(3, 2, 'Mark Daryl Gonzaga', 0, 0, 0, 0),
(4, 2, 'Marchie Clenuar Arado', 0, 0, 0, 0),
(5, 3, 'Carl Benson Cutanda', 0, 0, 0, 0),
(6, 3, 'Kristine Kaye Boltron', 0, 0, 0, 0),
(7, 4, 'Aldrin Louis Bagolor', 0, 0, 0, 0),
(8, 4, 'Cherry Maigne Arandid', 0, 0, 0, 0),
(9, 5, 'Derick James Rejas', 0, 0, 0, 0),
(10, 5, 'Cristine Joy Milay', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qa_two`
--

CREATE TABLE `qa_two` (
  `id` int(11) NOT NULL,
  `candidate_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `judge1` double NOT NULL,
  `judge2` double NOT NULL,
  `judge3` double NOT NULL,
  `average` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qa_two`
--

INSERT INTO `qa_two` (`id`, `candidate_no`, `name`, `judge1`, `judge2`, `judge3`, `average`) VALUES
(1, 1, 'Lourd Vincent Malaran', 0, 0, 0, 0),
(2, 1, 'Diosdada Joy Fano', 0, 0, 0, 0),
(3, 2, 'Mark Daryl Gonzaga', 0, 0, 0, 0),
(4, 2, 'Marchie Clenuar Arado', 0, 0, 0, 0),
(5, 3, 'Carl Benson Cutanda', 0, 0, 0, 0),
(6, 3, 'Kristine Kaye Boltron', 0, 0, 0, 0),
(7, 4, 'Aldrin Louis Bagolor', 0, 0, 0, 0),
(8, 4, 'Cherry Maigne Arandid', 0, 0, 0, 0),
(9, 5, 'Derick James Rejas', 0, 0, 0, 0),
(10, 5, 'Cristine Joy Milay', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `score_card`
--

CREATE TABLE `score_card` (
  `id` int(100) NOT NULL,
  `name_contestant` varchar(100) NOT NULL,
  `id_contestant` int(100) NOT NULL,
  `name_judge` varchar(100) NOT NULL,
  `talent_night` double(100,2) NOT NULL,
  `talent_night_vote` double(100,2) NOT NULL,
  `production_no` double(100,2) NOT NULL,
  `production_no_vote` double(100,2) NOT NULL,
  `shorts_wear` double(100,2) NOT NULL,
  `shorts_wear_vote` double(100,2) NOT NULL,
  `QA_one` double(100,2) NOT NULL,
  `QA_one_vote` double(100,2) NOT NULL,
  `long_gown` double(100,2) NOT NULL,
  `long_gown_vote` double(100,2) NOT NULL,
  `QA_two` double(100,2) NOT NULL,
  `QA_two_vote` double(100,2) NOT NULL,
  `grand_total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `score_card`
--

INSERT INTO `score_card` (`id`, `name_contestant`, `id_contestant`, `name_judge`, `talent_night`, `talent_night_vote`, `production_no`, `production_no_vote`, `shorts_wear`, `shorts_wear_vote`, `QA_one`, `QA_one_vote`, `long_gown`, `long_gown_vote`, `QA_two`, `QA_two_vote`, `grand_total`) VALUES
(1, 'Lourd Vincent Malaran', 1, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(2, 'Lourd Vincent Malaran', 1, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(3, 'Lourd Vincent Malaran', 1, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(4, 'Diosdada Joy Fano', 1, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(5, 'Diosdada Joy Fano', 1, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(6, 'Diosdada Joy Fano', 1, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(7, 'Mark Daryl Gonzaga', 2, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(8, 'Mark Daryl Gonzaga', 2, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(9, 'Mark Daryl Gonzaga', 2, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(10, 'Marchie Clenuar Arado', 2, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(11, 'Marchie Clenuar Arado', 2, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(12, 'Marchie Clenuar Arado', 2, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(13, 'Carl Benson Cutanda', 3, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(14, 'Carl Benson Cutanda', 3, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(15, 'Carl Benson Cutanda', 3, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(16, 'Kristine Kaye Boltron', 3, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(17, 'Kristine Kaye Boltron', 3, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(18, 'Kristine Kaye Boltron', 3, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(19, 'Aldrin Louis Bagolor', 4, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(20, 'Aldrin Louis Bagolor', 4, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(21, 'Aldrin Louis Bagolor', 4, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(22, 'Cherry Maigne Arandid', 4, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(23, 'Cherry Maigne Arandid', 4, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(24, 'Cherry Maigne Arandid', 4, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(25, 'Derick James Rejas', 5, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(26, 'Derick James Rejas', 5, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(27, 'Derick James Rejas', 5, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(28, 'Cristine Joy Milay', 5, 'judge1', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(29, 'Cristine Joy Milay', 5, 'judge2', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0),
(30, 'Cristine Joy Milay', 5, 'judge3', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shorts_wear`
--

CREATE TABLE `shorts_wear` (
  `id` int(11) NOT NULL,
  `candidate_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `judge1` double NOT NULL,
  `judge2` double NOT NULL,
  `judge3` double NOT NULL,
  `average` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shorts_wear`
--

INSERT INTO `shorts_wear` (`id`, `candidate_no`, `name`, `judge1`, `judge2`, `judge3`, `average`) VALUES
(1, 1, 'Lourd Vincent Malaran', 0, 0, 0, 0),
(2, 1, 'Diosdada Joy Fano', 0, 0, 0, 0),
(3, 2, 'Mark Daryl Gonzaga', 0, 0, 0, 0),
(4, 2, 'Marchie Clenuar Arado', 0, 0, 0, 0),
(5, 3, 'Carl Benson Cutanda', 0, 0, 0, 0),
(6, 3, 'Kristine Kaye Boltron', 0, 0, 0, 0),
(7, 4, 'Aldrin Louis Bagolor', 0, 0, 0, 0),
(8, 4, 'Cherry Maigne Arandid', 0, 0, 0, 0),
(9, 5, 'Derick James Rejas', 0, 0, 0, 0),
(10, 5, 'Cristine Joy Milay', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `talent_night`
--

CREATE TABLE `talent_night` (
  `id` int(11) NOT NULL,
  `candidate_no` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `judge1` double NOT NULL,
  `judge2` double NOT NULL,
  `judge3` double NOT NULL,
  `average` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `talent_night`
--

INSERT INTO `talent_night` (`id`, `candidate_no`, `name`, `judge1`, `judge2`, `judge3`, `average`) VALUES
(1, 1, 'Lourd Vincent Malaran', 0, 0, 0, 0),
(2, 1, 'Diosdada Joy Fano', 0, 0, 0, 0),
(3, 2, 'Mark Daryl Gonzaga', 0, 0, 0, 0),
(4, 2, 'Marchie Clenuar Arado', 0, 0, 0, 0),
(5, 3, 'Carl Benson Cutanda', 0, 0, 0, 0),
(6, 3, 'Kristine Kaye Boltron', 0, 0, 0, 0),
(7, 4, 'Aldrin Louis Bagolor', 0, 0, 0, 0),
(8, 4, 'Cherry Maigne Arandid', 0, 0, 0, 0),
(9, 5, 'Derick James Rejas', 0, 0, 0, 0),
(10, 5, 'Cristine Joy Milay', 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contestant`
--
ALTER TABLE `contestant`
  ADD PRIMARY KEY (`id_contestant`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `long_gown`
--
ALTER TABLE `long_gown`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `production_no`
--
ALTER TABLE `production_no`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_one`
--
ALTER TABLE `qa_one`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qa_two`
--
ALTER TABLE `qa_two`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `score_card`
--
ALTER TABLE `score_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shorts_wear`
--
ALTER TABLE `shorts_wear`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `talent_night`
--
ALTER TABLE `talent_night`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contestant`
--
ALTER TABLE `contestant`
  MODIFY `id_contestant` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `long_gown`
--
ALTER TABLE `long_gown`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `production_no`
--
ALTER TABLE `production_no`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `qa_one`
--
ALTER TABLE `qa_one`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `qa_two`
--
ALTER TABLE `qa_two`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `score_card`
--
ALTER TABLE `score_card`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `shorts_wear`
--
ALTER TABLE `shorts_wear`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `talent_night`
--
ALTER TABLE `talent_night`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
