<?php
	session_start();
	$link = mysqli_connect('localhost','root','','tabulation');
	
?>